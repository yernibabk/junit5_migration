package com.pluralsight.migratingjunit4junit5.airport;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {FlightsConfiguration.class})
public class FlightWithPassengersSpringTest {

    @Autowired
    private DistancesManager distancesManager;

    @Autowired
    @Qualifier("flight1")
    private Flight flight1;

    @Autowired
    @Qualifier("flight2")
    private Flight flight2;

    @Autowired
    @Qualifier("flight3")
    private Flight flight3;

    @Test
    public void testSellTickets() {
        assertEquals(50, flight1.getPassengersNumber());
        assertThrows(RuntimeException.class,
                () -> flight1.addPassenger(new Passenger("124-56-7890", "Michael Johnson", "US")));
    }

    @Test
    public void testAddRemovePassengers() throws IOException {
        flight1.setPlaces(51);
        Passenger additionalPassenger = new Passenger("124-56-7890", "Michael Johnson", "US");
        flight1.addPassenger(additionalPassenger);
        assertEquals(51, flight1.getPassengersNumber());
        flight1.removePassenger(additionalPassenger);
        assertEquals(50, flight1.getPassengersNumber());
        assertEquals(51, flight1.getPlaces());
    }

    @Test
    public void testSetInvalidPlaces() {
        assertEquals(50, flight1.getPassengersNumber());
        assertThrows(RuntimeException.class,
                () -> flight1.setPlaces(49));
    }

    @Test
    public void testSetValidPlaces() throws IOException {
        assertEquals(50, flight1.getPassengersNumber());
        flight1.setPlaces(52);
        assertEquals(52, flight1.getPlaces());
    }

    @Test
    public void testFlightsDistances() {

        for (Passenger passenger : flight1.getPassengersSet()) {
            distancesManager.addDistance(passenger, flight1.getDistance());
        }

        for (Passenger passenger : flight2.getPassengersSet()) {
            distancesManager.addDistance(passenger, flight2.getDistance());
        }

        for (Passenger passenger : flight3.getPassengersSet()) {
            distancesManager.addDistance(passenger, flight3.getDistance());
        }

        distancesManager.calculateGivenPoints();

        assertEquals(210, distancesManager.getPassengersPointsMap().get(new Passenger("900-45-6809", "Susan Todd", "GB")).longValue());
        assertEquals(420, distancesManager.getPassengersPointsMap().get(new Passenger("900-45-6797", "Harry Christensen", "GB")).longValue());
        assertEquals(630, distancesManager.getPassengersPointsMap().get(new Passenger("123-45-6799", "Bethany King", "US")).longValue());
    }

}
