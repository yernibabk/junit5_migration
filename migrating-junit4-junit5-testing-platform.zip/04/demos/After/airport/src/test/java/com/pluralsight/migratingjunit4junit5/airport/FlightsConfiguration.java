package com.pluralsight.migratingjunit4junit5.airport;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;

@Configuration
public class FlightsConfiguration {
    @Bean
    public Flight flight1() throws IOException {
        return FlightBuilderUtil.buildFlightFromCsv("AA1234", 50,"src/test/resources/flights_information.csv");
    }

    @Bean
    public Flight flight2() throws IOException {
        return FlightBuilderUtil.buildFlightFromCsv("AA1235", 36,"src/test/resources/flights_information2.csv");
    }

    @Bean
    public Flight flight3() throws IOException {
        return FlightBuilderUtil.buildFlightFromCsv("AA1236", 24,"src/test/resources/flights_information3.csv");
    }

    @Bean
    public DistancesManager distancesManager() {
        return new DistancesManager();
    }
}
