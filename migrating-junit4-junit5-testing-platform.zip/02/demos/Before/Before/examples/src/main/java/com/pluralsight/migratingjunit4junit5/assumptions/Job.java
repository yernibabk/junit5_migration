package com.pluralsight.migratingjunit4junit5.assumptions;

public class Job {
}
