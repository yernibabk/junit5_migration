package com.pluralsight.migratingjunit4junit5.suites;

import com.pluralsight.migratingjunit4junit5.categories.JUnit4CustomerTest;
import com.pluralsight.migratingjunit4junit5.categories.JUnit4CustomersRepositoryTest;
import com.pluralsight.migratingjunit4junit5.categories.RepositoryTests;
import org.junit.experimental.categories.Categories;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Categories.class)
@Categories.ExcludeCategory(RepositoryTests.class)
@Suite.SuiteClasses({JUnit4CustomerTest.class, JUnit4CustomersRepositoryTest.class})
public class JUnit4ExcludeRepositoryTestsSuite {
}
