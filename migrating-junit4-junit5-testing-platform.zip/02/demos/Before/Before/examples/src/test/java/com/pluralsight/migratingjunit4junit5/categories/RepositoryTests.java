package com.pluralsight.migratingjunit4junit5.categories;

public interface RepositoryTests {
}
